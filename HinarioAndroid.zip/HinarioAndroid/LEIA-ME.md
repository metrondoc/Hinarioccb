# Hinário: app Android sem anúncios

Este app funciona 100% offline. Ele nem pede permissão de internet. Os hinos, os favoritos e o tamanho da letra ficam salvos no próprio celular.

## Como gerar o APK

1. Descompacte esta pasta no notebook.
2. Abra o **Android Studio** e vá em **File › Open**. Escolha a pasta `HinarioAndroid`.
3. Espere o Gradle sincronizar. Na primeira vez ele baixa as dependências, então precisa de internet.
4. Vá em **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
5. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
6. Passe o APK para o celular e instale. Pode ser preciso permitir "instalar apps desconhecidos".

Você também pode ligar o celular no cabo, com a depuração USB ativa, e apertar **Run ▶**.

## Já trazer os hinos dentro do app (opcional)

Coloque seu arquivo de hinos em `app/src/main/assets/` com o nome **`hinos.txt`** ou **`hinos.json`** antes de gerar o APK. O app carrega esses hinos na primeira vez que abrir.

Você também pode deixar sem arquivo e usar **Ajustes › Escolher arquivo** dentro do app.

### Formato do .txt
```
Hino 1 - Título do hino
primeira linha
segunda linha

Coro:
linha do coro

Hino 2 - Outro título
...
```
- Cada hino começa com `Hino N - Título`. Também funciona `N - Título`.
- As estrofes ficam separadas por uma linha em branco.
- Uma estrofe que começa com "Coro" aparece destacada.

### Formato do .json
```json
[{"numero": 1, "titulo": "Título", "letra": "linha 1\nlinha 2\n\nCoro:\n..."}]
```

## O que o app faz
- Busca por número ou por palavra do título ou da letra
- Aumenta e diminui a letra (A− / A+)
- Favoritos com estrela
- Desliza o dedo para o lado para ir ao hino anterior ou ao próximo
- Mantém a tela acesa enquanto o hino está aberto
- Edita ou cria um hino na mão (ícone do lápis)
- Salva um backup em arquivo .json (Ajustes)
- O botão voltar do Android fecha o painel e depois volta para a lista
- Segue o modo escuro do celular

## Onde mexer
- Telas e funções: `app/src/main/assets/index.html`
- Parte nativa (arquivos, tela acesa, botão voltar): `app/src/main/java/br/com/uelber/hinario/MainActivity.kt`
- Nome do app: `app/src/main/res/values/strings.xml`
- Ícone: `app/src/main/res/drawable/ic_launcher_foreground.xml`
