package br.com.uelber.hinario

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Hinário offline e sem anúncios.
 * A interface fica em assets/index.html; os hinos ficam salvos no próprio celular.
 * Se você colocar um arquivo assets/hinos.txt (ou hinos.json) antes de compilar,
 * o app já abre com os hinos carregados.
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackup: String? = null

    // Escolher arquivo para importar
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            fileCallback = null
        }

    // Salvar backup em arquivo
    private val saveFile =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val data = pendingBackup
            pendingBackup = null
            if (uri != null && data != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                    toast("Backup salvo.")
                } catch (e: Exception) {
                    toast("Não consegui salvar o backup.")
                }
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true      // guarda hinos, favoritos e tamanho da letra
            allowFileAccess = false
            allowContentAccess = true
            textZoom = 100
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    pickFile.launch("*/*")
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Ponte(), "Android")

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }

        // Botão voltar: fecha painel / volta para a lista antes de sair do app
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.appBack && window.appBack()) ? 'sim' : 'nao'") { r ->
                    if (r?.contains("sim") != true) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** Funções que a página chama como Android.xxx(...) */
    inner class Ponte {
        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackup = json
                saveFile.launch("hinario-backup.json")
            }
        }

        /** Texto de assets/hinos.json ou assets/hinos.txt, se existir. */
        @JavascriptInterface
        fun bundled(): String {
            for (nome in listOf("hinos.json", "hinos.txt")) {
                try {
                    return assets.open(nome).bufferedReader(Charsets.UTF_8).use { it.readText() }
                } catch (_: Exception) {
                }
            }
            return ""
        }
    }
}
